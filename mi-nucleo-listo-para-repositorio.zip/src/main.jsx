import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import MiNucleoApp from "./mi-nucleo/MiNucleoApp.jsx";
import "./styles.css";
import "./premium.css";
import "./mi-nucleo/mi-nucleo.css";

const pathname = String(globalThis.location?.pathname || "/").replace(/\/+$/, "") || "/";
const RootExperience = pathname === "/mi-nucleo" ? MiNucleoApp : App;

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <RootExperience />
  </React.StrictMode>
);
