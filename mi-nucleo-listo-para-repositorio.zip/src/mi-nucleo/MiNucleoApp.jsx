import React, { useEffect, useMemo, useState } from "react";
import {
  ArrowUpRight,
  BookOpen,
  BriefcaseBusiness,
  CheckCircle2,
  GraduationCap,
  LoaderCircle,
  LockKeyhole,
  LogOut,
  Mail,
  ShieldCheck,
  Sparkles,
  UserRound,
  UserPlus
} from "lucide-react";
import { isSupabaseConfigured, supabase } from "../lib/supabaseClient.js";
import { getOrCreateUserApproval } from "../lib/userApproval.js";
import {
  CONSENT_VERSION,
  getPortalIdentity,
  hasCurrentConsent,
  savePortalConsent,
  savePortalProfile
} from "./portalStore.js";

const PRODUCT_LINKS = {
  escucha: import.meta.env.VITE_ESCUCHA_VIVA_URL || "https://psicoldp-simulador-limpio.vercel.app/",
  empresa: "https://www.nucleovivo.net/lab/empresa-viva/app/",
  umbral: "https://www.nucleovivo.net/lab/umbral-docente/app/",
  sembrar: "https://www.nucleovivo.net/sembrar/aula/"
};

const AREA_OPTIONS = [
  {
    id: "psicologia",
    label: "Psicología",
    description: "Entrevistas, práctica formativa y desarrollo de habilidades clínicas."
  },
  {
    id: "docencia",
    label: "Docencia y educación",
    description: "Formación, bienestar docente, planificación y experiencias educativas."
  },
  {
    id: "empresa",
    label: "Administración e Ing. Comercial",
    description: "Decisiones empresariales, gestión, estrategia y desarrollo organizacional."
  },
  {
    id: "transversal",
    label: "Explorar todo",
    description: "Quiero navegar el ecosistema completo sin priorizar un área."
  }
];

const PRODUCTS = [
  {
    key: "escucha",
    title: "Escucha Viva",
    category: "Psicología · Núcleo Vivo Lab",
    description: "Simulación formativa de entrevistas psicológicas con práctica, continuidad y retroalimentación.",
    icon: UserRound,
    areas: ["psicologia", "transversal"]
  },
  {
    key: "empresa",
    title: "Empresa Viva",
    category: "Administración · Núcleo Vivo Lab",
    description: "Simulador de decisiones empresariales para analizar escenarios y responder bajo presión.",
    icon: BriefcaseBusiness,
    areas: ["empresa", "transversal"]
  },
  {
    key: "umbral",
    title: "Umbral Docente",
    category: "Docencia · Núcleo Vivo Lab",
    description: "Herramientas y experiencias aplicadas para acompañar decisiones y desafíos del trabajo educativo.",
    icon: GraduationCap,
    areas: ["docencia", "transversal"]
  },
  {
    key: "sembrar",
    title: "Aula Sembrar",
    category: "Formación · Sembrar",
    description: "Cursos y experiencias de aprendizaje, incluyendo IA con criterio humano y bienestar docente.",
    icon: BookOpen,
    areas: ["docencia", "psicologia", "empresa", "transversal"]
  }
];

export default function MiNucleoApp() {
  const [authSession, setAuthSession] = useState(null);
  const [loading, setLoading] = useState(isSupabaseConfigured);
  const [identity, setIdentity] = useState(null);
  const [approvalState, setApprovalState] = useState({ status: "checking", error: "" });
  const [notice, setNotice] = useState("");

  useEffect(() => {
    if (!isSupabaseConfigured || !supabase) {
      setLoading(false);
      return undefined;
    }

    let mounted = true;

    async function applySession(nextSession) {
      if (!mounted) return;
      setAuthSession(nextSession || null);

      if (!nextSession?.user) {
        setIdentity(null);
        setApprovalState({ status: "signed_out", error: "" });
        setLoading(false);
        return;
      }

      const [nextIdentity, nextApproval] = await Promise.all([
        getPortalIdentity(nextSession.user),
        getOrCreateUserApproval(nextSession.user)
      ]);

      if (!mounted) return;
      setIdentity(nextIdentity);
      setApprovalState(nextApproval);
      setLoading(false);
    }

    supabase.auth.getSession().then(({ data, error }) => {
      if (error) setNotice("No pudimos recuperar tu sesión. Intenta iniciar sesión nuevamente.");
      void applySession(data?.session || null);
    });

    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      globalThis.setTimeout(() => void applySession(nextSession), 0);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  async function refreshIdentity() {
    if (!authSession?.user) return;
    const { data } = await supabase.auth.getUser();
    const nextUser = data?.user || authSession.user;
    const nextIdentity = await getPortalIdentity(nextUser);
    setAuthSession((current) => (current ? { ...current, user: nextUser } : current));
    setIdentity(nextIdentity);
  }

  async function handleSignOut() {
    if (supabase) await supabase.auth.signOut();
    setAuthSession(null);
    setIdentity(null);
    setApprovalState({ status: "signed_out", error: "" });
  }

  if (loading) {
    return <PortalLoading />;
  }

  if (!isSupabaseConfigured || !supabase) {
    return (
      <PortalFrame>
        <section className="mn-state-card">
          <ShieldCheck aria-hidden="true" />
          <span className="mn-eyebrow">Configuración</span>
          <h1>Mi Núcleo aún no puede conectarse.</h1>
          <p>
            Esta ruta necesita las mismas variables <strong>VITE_SUPABASE_URL</strong> y{" "}
            <strong>VITE_SUPABASE_ANON_KEY</strong> que ya utiliza Escucha Viva.
          </p>
        </section>
      </PortalFrame>
    );
  }

  if (!authSession?.user) {
    return <MiNucleoAuth />;
  }

  if (!hasCurrentConsent(identity, authSession.user)) {
    return (
      <ConsentGate
        user={authSession.user}
        onAccepted={async () => {
          await refreshIdentity();
          setNotice("Preferencias de privacidad registradas.");
        }}
        onSignOut={handleSignOut}
      />
    );
  }

  if (!identity?.area) {
    return (
      <ProfileSetup
        user={authSession.user}
        onSaved={async () => {
          await refreshIdentity();
          setNotice("Perfil actualizado.");
        }}
        onSignOut={handleSignOut}
      />
    );
  }

  return (
    <Dashboard
      user={authSession.user}
      identity={identity}
      approvalState={approvalState}
      notice={notice}
      onClearNotice={() => setNotice("")}
      onSignOut={handleSignOut}
      onProfileSaved={refreshIdentity}
    />
  );
}

function MiNucleoAuth() {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [working, setWorking] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const redirectTo = `${globalThis.location?.origin || "https://psicoldp-simulador-limpio.vercel.app"}/mi-nucleo`;

  async function submit(event) {
    event.preventDefault();
    setMessage("");
    setError("");
    setWorking(true);

    try {
      if (mode === "register") {
        const { error: signUpError } = await supabase.auth.signUp({
          email: form.email,
          password: form.password,
          options: {
            emailRedirectTo: redirectTo,
            data: {
              full_name: form.name,
              name: form.name,
              mi_nucleo_origin: "portal"
            }
          }
        });
        if (signUpError) throw signUpError;
        setMessage("Cuenta creada. Revisa tu correo para confirmar el acceso y vuelve a Mi Núcleo.");
      } else if (mode === "reset") {
        const { error: resetError } = await supabase.auth.resetPasswordForEmail(form.email, {
          redirectTo
        });
        if (resetError) throw resetError;
        setMessage("Si el correo está registrado, recibirás instrucciones para recuperar tu contraseña.");
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: form.email,
          password: form.password
        });
        if (signInError) throw signInError;
      }
    } catch (authError) {
      setError(mapAuthError(authError));
    } finally {
      setWorking(false);
    }
  }

  async function signInWithGoogle() {
    setMessage("");
    setError("");
    setWorking(true);
    try {
      const { error: oauthError } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: { redirectTo }
      });
      if (oauthError) throw oauthError;
    } catch (oauthError) {
      setError(
        String(oauthError?.message || "").toLowerCase().includes("provider")
          ? "El acceso con Google aún no está habilitado en Supabase. Puedes entrar con correo y contraseña mientras lo activamos."
          : mapAuthError(oauthError)
      );
      setWorking(false);
    }
  }

  return (
    <PortalFrame auth>
      <div className="mn-auth-grid">
        <section className="mn-auth-copy">
          <span className="mn-eyebrow">Tu espacio dentro de Núcleo Vivo</span>
          <h1>Todo tu ecosistema, desde un solo lugar.</h1>
          <p>
            Accede a simuladores, formación y herramientas con una identidad común. La tecnología
            organiza el acceso; las personas siguen al centro.
          </p>
          <div className="mn-auth-points">
            <span><CheckCircle2 /> Una cuenta para Mi Núcleo</span>
            <span><CheckCircle2 /> Perfil que ordena tus experiencias</span>
            <span><CheckCircle2 /> Privacidad visible y revisable</span>
          </div>
        </section>

        <section className="mn-auth-card">
          <header>
            <span className="mn-eyebrow">Mi Núcleo</span>
            <h2>{mode === "register" ? "Crear cuenta" : mode === "reset" ? "Recuperar acceso" : "Iniciar sesión"}</h2>
          </header>

          <button className="mn-google-button" type="button" onClick={signInWithGoogle} disabled={working}>
            <span className="mn-google-mark">G</span>
            Continuar con Google
          </button>

          <div className="mn-divider"><span>o</span></div>

          <form className="mn-form" onSubmit={submit}>
            {mode === "register" && (
              <label>
                Nombre
                <div className="mn-input-wrap">
                  <UserRound aria-hidden="true" />
                  <input
                    type="text"
                    autoComplete="name"
                    required
                    value={form.name}
                    onChange={(event) => setForm({ ...form, name: event.target.value })}
                  />
                </div>
              </label>
            )}

            <label>
              Correo
              <div className="mn-input-wrap">
                <Mail aria-hidden="true" />
                <input
                  type="email"
                  autoComplete="email"
                  required
                  value={form.email}
                  onChange={(event) => setForm({ ...form, email: event.target.value })}
                />
              </div>
            </label>

            {mode !== "reset" && (
              <label>
                Contraseña
                <div className="mn-input-wrap">
                  <LockKeyhole aria-hidden="true" />
                  <input
                    type="password"
                    autoComplete={mode === "register" ? "new-password" : "current-password"}
                    minLength={6}
                    required
                    value={form.password}
                    onChange={(event) => setForm({ ...form, password: event.target.value })}
                  />
                </div>
              </label>
            )}

            {error && <p className="mn-message mn-message-error">{error}</p>}
            {message && <p className="mn-message mn-message-ok">{message}</p>}

            <button className="mn-primary-button" type="submit" disabled={working}>
              {working ? <LoaderCircle className="mn-spin" /> : mode === "register" ? <UserPlus /> : <LockKeyhole />}
              {mode === "register" ? "Crear cuenta" : mode === "reset" ? "Enviar recuperación" : "Entrar a Mi Núcleo"}
            </button>
          </form>

          <div className="mn-auth-links">
            <button type="button" onClick={() => setMode(mode === "register" ? "login" : "register")}>
              {mode === "register" ? "Ya tengo cuenta" : "Crear cuenta"}
            </button>
            <button type="button" onClick={() => setMode(mode === "reset" ? "login" : "reset")}>
              {mode === "reset" ? "Volver" : "Olvidé mi contraseña"}
            </button>
          </div>
        </section>
      </div>
    </PortalFrame>
  );
}

function ConsentGate({ user, onAccepted, onSignOut }) {
  const [privacy, setPrivacy] = useState(false);
  const [terms, setTerms] = useState(false);
  const [working, setWorking] = useState(false);
  const [error, setError] = useState("");

  async function accept() {
    if (!privacy || !terms) return;
    setWorking(true);
    setError("");
    const result = await savePortalConsent(user);
    if (result.error) {
      setError(result.error);
      setWorking(false);
      return;
    }
    await onAccepted();
    setWorking(false);
  }

  return (
    <PortalFrame>
      <section className="mn-consent-card">
        <div className="mn-consent-icon"><ShieldCheck /></div>
        <span className="mn-eyebrow">Antes de entrar</span>
        <h1>Tu información, con reglas claras.</h1>
        <p>
          Mi Núcleo usa tus datos de cuenta para identificarte, recordar tus preferencias y ordenar
          las experiencias a las que accedes. No usaremos tus conversaciones de simulación para
          personalizar publicidad.
        </p>

        <div className="mn-consent-options">
          <label>
            <input type="checkbox" checked={privacy} onChange={(event) => setPrivacy(event.target.checked)} />
            <span>
              He leído y acepto la{" "}
              <a href="https://www.nucleovivo.net/privacidad/" target="_blank" rel="noreferrer">
                Política de Privacidad
              </a>.
            </span>
          </label>
          <label>
            <input type="checkbox" checked={terms} onChange={(event) => setTerms(event.target.checked)} />
            <span>
              He leído y acepto los{" "}
              <a href="https://www.nucleovivo.net/terminos/" target="_blank" rel="noreferrer">
                Términos y Condiciones
              </a>.
            </span>
          </label>
        </div>

        <small>Versión de consentimiento: {CONSENT_VERSION}</small>
        {error && <p className="mn-message mn-message-error">{error}</p>}

        <div className="mn-consent-actions">
          <button className="mn-primary-button" type="button" disabled={!privacy || !terms || working} onClick={accept}>
            {working ? <LoaderCircle className="mn-spin" /> : <ShieldCheck />}
            Aceptar y continuar
          </button>
          <button className="mn-text-button" type="button" onClick={onSignOut}>
            Salir de esta cuenta
          </button>
        </div>
      </section>
    </PortalFrame>
  );
}

function ProfileSetup({ user, onSaved, onSignOut }) {
  const [area, setArea] = useState("");
  const [working, setWorking] = useState(false);
  const [error, setError] = useState("");

  async function save() {
    if (!area) return;
    setWorking(true);
    const result = await savePortalProfile(user, { area });
    if (result.error) {
      setError(result.error);
      setWorking(false);
      return;
    }
    await onSaved();
    setWorking(false);
  }

  return (
    <PortalFrame>
      <section className="mn-onboarding-card">
        <span className="mn-eyebrow">Personaliza Mi Núcleo</span>
        <h1>¿Qué área quieres ver primero?</h1>
        <p>No te encierra en una categoría. Solo ordena el panel para que lo más relevante aparezca arriba.</p>

        <div className="mn-area-grid">
          {AREA_OPTIONS.map((option) => (
            <button
              className={`mn-area-option ${area === option.id ? "selected" : ""}`}
              type="button"
              key={option.id}
              onClick={() => setArea(option.id)}
            >
              <strong>{option.label}</strong>
              <span>{option.description}</span>
            </button>
          ))}
        </div>

        {error && <p className="mn-message mn-message-error">{error}</p>}
        <div className="mn-consent-actions">
          <button className="mn-primary-button" type="button" disabled={!area || working} onClick={save}>
            {working ? <LoaderCircle className="mn-spin" /> : <Sparkles />}
            Preparar mi espacio
          </button>
          <button className="mn-text-button" type="button" onClick={onSignOut}>Cerrar sesión</button>
        </div>
      </section>
    </PortalFrame>
  );
}

function Dashboard({ user, identity, approvalState, notice, onClearNotice, onSignOut, onProfileSaved }) {
  const [editingArea, setEditingArea] = useState(false);
  const [area, setArea] = useState(identity.area || "transversal");
  const [savingArea, setSavingArea] = useState(false);

  const firstName =
    String(identity.fullName || user.user_metadata?.full_name || user.user_metadata?.name || "")
      .trim()
      .split(/\s+/)[0] || "Hola";

  const orderedProducts = useMemo(() => {
    return [...PRODUCTS].sort((a, b) => {
      const aScore = a.areas.includes(identity.area) ? 0 : 1;
      const bScore = b.areas.includes(identity.area) ? 0 : 1;
      return aScore - bScore;
    });
  }, [identity.area]);

  async function saveArea() {
    setSavingArea(true);
    await savePortalProfile(user, { area });
    await onProfileSaved();
    setSavingArea(false);
    setEditingArea(false);
  }

  return (
    <div className="mn-dashboard-shell">
      <header className="mn-dashboard-header">
        <a className="mn-brand" href="https://www.nucleovivo.net/" aria-label="Núcleo Vivo">
          <img src="/nucleo-vivo-logo-horizontal.png" alt="Núcleo Vivo" />
        </a>
        <div className="mn-header-actions">
          <span className="mn-user-chip"><UserRound /> {user.email}</span>
          <button className="mn-icon-button" type="button" onClick={onSignOut} title="Cerrar sesión">
            <LogOut />
          </button>
        </div>
      </header>

      <main className="mn-dashboard-main">
        {notice && (
          <button className="mn-notice" type="button" onClick={onClearNotice}>
            <CheckCircle2 /> {notice}
          </button>
        )}

        <section className="mn-hero-panel">
          <div>
            <span className="mn-eyebrow">Mi Núcleo</span>
            <h1>{firstName === "Hola" ? "Hola." : `Hola, ${firstName}.`}</h1>
            <p>Este es tu punto de entrada a las experiencias, simuladores y formación de Núcleo Vivo.</p>
          </div>
          <div className="mn-orbit" aria-hidden="true">
            <span></span><span></span><span></span>
            <div>NV</div>
          </div>
        </section>

        <section className="mn-section">
          <header className="mn-section-heading">
            <div>
              <span className="mn-eyebrow">Mis experiencias</span>
              <h2>Empieza por lo que tiene más sentido para ti.</h2>
            </div>
            <span className="mn-area-badge">
              {AREA_OPTIONS.find((option) => option.id === identity.area)?.label || "Explorar todo"}
            </span>
          </header>

          <div className="mn-product-grid">
            {orderedProducts.map((product) => (
              <ProductCard key={product.key} product={product} approvalState={approvalState} />
            ))}
          </div>
        </section>

        <section className="mn-account-grid">
          <article className="mn-account-card">
            <span className="mn-eyebrow">Mi perfil</span>
            <h3>Ordena tu experiencia</h3>
            {!editingArea ? (
              <>
                <p>
                  Área principal: <strong>{AREA_OPTIONS.find((option) => option.id === identity.area)?.label}</strong>
                </p>
                <button className="mn-secondary-button" type="button" onClick={() => setEditingArea(true)}>
                  Cambiar preferencia
                </button>
              </>
            ) : (
              <>
                <select value={area} onChange={(event) => setArea(event.target.value)}>
                  {AREA_OPTIONS.map((option) => (
                    <option key={option.id} value={option.id}>{option.label}</option>
                  ))}
                </select>
                <div className="mn-inline-actions">
                  <button className="mn-secondary-button" type="button" onClick={saveArea} disabled={savingArea}>
                    {savingArea ? "Guardando..." : "Guardar"}
                  </button>
                  <button className="mn-text-button" type="button" onClick={() => setEditingArea(false)}>Cancelar</button>
                </div>
              </>
            )}
          </article>

          <article className="mn-account-card">
            <span className="mn-eyebrow">Privacidad y mis datos</span>
            <h3>Control visible</h3>
            <p>
              Consentimiento vigente: <strong>{identity.consentVersion || CONSENT_VERSION}</strong>
            </p>
            <p className="mn-small">
              Puedes revisar en cualquier momento las políticas y solicitar acceso, rectificación o eliminación de tus datos.
            </p>
            <div className="mn-inline-actions">
              <a className="mn-secondary-button" href="https://www.nucleovivo.net/privacidad/" target="_blank" rel="noreferrer">
                Revisar privacidad
              </a>
              <a className="mn-text-link" href="mailto:contacto@nucleovivo.net">contacto@nucleovivo.net</a>
            </div>
          </article>
        </section>
      </main>
    </div>
  );
}

function ProductCard({ product, approvalState }) {
  const Icon = product.icon;
  const isEscucha = product.key === "escucha";
  const approved = approvalState?.status === "approved";
  const pending = approvalState?.status === "pending";

  let status = "Disponible";
  let action = "Abrir experiencia";

  if (isEscucha && approved) {
    status = "Habilitado";
    action = "Entrar a Escucha Viva";
  } else if (isEscucha && pending) {
    status = "Pendiente de aprobación";
    action = "Revisar acceso";
  } else if (isEscucha && !approved) {
    status = "Acceso por habilitar";
    action = "Ir a Escucha Viva";
  } else if (product.key === "sembrar") {
    status = "Disponible · cuenta actual";
    action = "Ir a Aula Sembrar";
  }

  return (
    <article className={`mn-product-card mn-product-${product.key}`}>
      <div className="mn-product-top">
        <span className="mn-product-icon"><Icon /></span>
        <span className="mn-status-pill">{status}</span>
      </div>
      <span className="mn-product-category">{product.category}</span>
      <h3>{product.title}</h3>
      <p>{product.description}</p>
      <a href={PRODUCT_LINKS[product.key]} target={isEscucha ? "_self" : "_blank"} rel="noreferrer">
        {action} <ArrowUpRight />
      </a>
    </article>
  );
}

function PortalFrame({ children, auth = false }) {
  return (
    <main className={`mn-portal-shell ${auth ? "mn-auth-shell" : ""}`}>
      <header className="mn-portal-brand">
        <a href="https://www.nucleovivo.net/">
          <img src="/nucleo-vivo-logo-horizontal.png" alt="Núcleo Vivo" />
        </a>
        <span>Mi Núcleo</span>
      </header>
      {children}
      <footer className="mn-portal-footer">
        <span>Personas al centro · Tecnología como apoyo.</span>
        <a href="mailto:contacto@nucleovivo.net">Ayuda</a>
      </footer>
    </main>
  );
}

function PortalLoading() {
  return (
    <PortalFrame>
      <section className="mn-state-card">
        <LoaderCircle className="mn-spin" />
        <span className="mn-eyebrow">Mi Núcleo</span>
        <h1>Preparando tu espacio</h1>
        <p>Estamos recuperando tu identidad y tus preferencias.</p>
      </section>
    </PortalFrame>
  );
}

function mapAuthError(error) {
  const text = String(error?.message || error || "").toLowerCase();
  if (text.includes("invalid login credentials")) return "Correo o contraseña incorrectos.";
  if (text.includes("email not confirmed")) return "Debes confirmar tu correo antes de entrar.";
  if (text.includes("already registered") || text.includes("already exists")) {
    return "Este correo ya está registrado. Intenta iniciar sesión o recuperar tu contraseña.";
  }
  if (text.includes("signup") && text.includes("disabled")) return "El registro está temporalmente deshabilitado.";
  if (text.includes("failed to fetch") || text.includes("network")) return "No pudimos conectar con Supabase. Revisa tu conexión.";
  return error?.message || "No pudimos completar la acción.";
}
