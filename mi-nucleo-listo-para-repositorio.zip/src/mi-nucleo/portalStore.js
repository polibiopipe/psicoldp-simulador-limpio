import { supabase } from "../lib/supabaseClient.js";

export const CONSENT_VERSION = "mi-nucleo-2026-08-15-v1";

const AREA_VALUES = new Set(["psicologia", "docencia", "empresa", "transversal"]);

export async function getPortalIdentity(user) {
  if (!user) return emptyIdentity();

  const metadata = user.user_metadata || {};
  const fallback = {
    fullName: metadata.full_name || metadata.name || "",
    area: AREA_VALUES.has(metadata.mi_nucleo_area) ? metadata.mi_nucleo_area : "",
    consentVersion: metadata.mi_nucleo_consent_version || "",
    consentAcceptedAt: metadata.mi_nucleo_consent_accepted_at || "",
    source: "auth_metadata"
  };

  if (!supabase) return fallback;

  try {
    const [profileResult, consentResult] = await Promise.all([
      supabase
        .from("mi_nucleo_profiles")
        .select("full_name,area,updated_at")
        .eq("user_id", user.id)
        .maybeSingle(),
      supabase
        .from("mi_nucleo_consents")
        .select("version,accepted,accepted_at")
        .eq("user_id", user.id)
        .eq("consent_type", "portal_required")
        .eq("accepted", true)
        .order("accepted_at", { ascending: false })
        .limit(1)
        .maybeSingle()
    ]);

    const profile = profileResult?.data || null;
    const consent = consentResult?.data || null;

    return {
      fullName: profile?.full_name || fallback.fullName,
      area: AREA_VALUES.has(profile?.area) ? profile.area : fallback.area,
      consentVersion: consent?.version || fallback.consentVersion,
      consentAcceptedAt: consent?.accepted_at || fallback.consentAcceptedAt,
      source: profile || consent ? "portal_tables" : fallback.source
    };
  } catch {
    return fallback;
  }
}

export function hasCurrentConsent(identity, user) {
  const metadata = user?.user_metadata || {};
  return (
    identity?.consentVersion === CONSENT_VERSION ||
    metadata.mi_nucleo_consent_version === CONSENT_VERSION
  );
}

export async function savePortalConsent(user) {
  if (!user || !supabase) return { error: "No pudimos validar tu cuenta." };

  const acceptedAt = new Date().toISOString();
  const metadata = {
    ...(user.user_metadata || {}),
    mi_nucleo_consent_version: CONSENT_VERSION,
    mi_nucleo_consent_accepted_at: acceptedAt,
    mi_nucleo_privacy_accepted: true,
    mi_nucleo_terms_accepted: true
  };

  const { error: metadataError } = await supabase.auth.updateUser({ data: metadata });
  if (metadataError) return { error: metadataError.message };

  try {
    await supabase.from("mi_nucleo_consents").upsert(
      {
        user_id: user.id,
        consent_type: "portal_required",
        version: CONSENT_VERSION,
        accepted: true,
        accepted_at: acceptedAt,
        source: "mi_nucleo"
      },
      { onConflict: "user_id,consent_type,version" }
    );
  } catch {
    // El portal sigue operativo con Auth metadata hasta aplicar la migración SQL.
  }

  return { error: "" };
}

export async function savePortalProfile(user, { area }) {
  if (!user || !supabase) return { error: "No pudimos validar tu cuenta." };
  if (!AREA_VALUES.has(area)) return { error: "Selecciona un área válida." };

  const fullName = user.user_metadata?.full_name || user.user_metadata?.name || "";
  const metadata = {
    ...(user.user_metadata || {}),
    mi_nucleo_area: area,
    mi_nucleo_onboarding_completed: true
  };

  const { error: metadataError } = await supabase.auth.updateUser({ data: metadata });
  if (metadataError) return { error: metadataError.message };

  try {
    await supabase.from("mi_nucleo_profiles").upsert(
      {
        user_id: user.id,
        full_name: fullName,
        area,
        onboarding_completed: true,
        updated_at: new Date().toISOString()
      },
      { onConflict: "user_id" }
    );
  } catch {
    // Fallback deliberado a Auth metadata mientras no exista la tabla.
  }

  return { error: "" };
}

function emptyIdentity() {
  return {
    fullName: "",
    area: "",
    consentVersion: "",
    consentAcceptedAt: "",
    source: ""
  };
}
