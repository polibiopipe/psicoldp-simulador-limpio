-- Mi Núcleo · identidad y consentimiento central
-- Diseñado para ejecutarse en el MISMO proyecto Supabase que usa Escucha Viva.
-- El frontend funciona con Auth metadata aunque esta migración aún no esté aplicada;
-- al aplicarla, agrega trazabilidad y RLS sin cambiar el flujo de acceso.

begin;

create extension if not exists pgcrypto;

create table if not exists public.mi_nucleo_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  area text check (area in ('psicologia', 'docencia', 'empresa', 'transversal')),
  onboarding_completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.mi_nucleo_consents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  consent_type text not null,
  version text not null,
  accepted boolean not null,
  accepted_at timestamptz not null default now(),
  withdrawn_at timestamptz,
  source text not null default 'mi_nucleo',
  context jsonb not null default '{}'::jsonb,
  unique (user_id, consent_type, version)
);

create table if not exists public.mi_nucleo_product_access (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_key text not null,
  status text not null default 'available'
    check (status in ('available', 'pending', 'active', 'expired', 'blocked')),
  source text not null default 'manual',
  starts_at timestamptz,
  ends_at timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, product_key)
);

create index if not exists mi_nucleo_consents_user_idx
  on public.mi_nucleo_consents(user_id, accepted_at desc);

create index if not exists mi_nucleo_product_access_user_idx
  on public.mi_nucleo_product_access(user_id);

create or replace function public.mi_nucleo_touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists mi_nucleo_profiles_touch on public.mi_nucleo_profiles;
create trigger mi_nucleo_profiles_touch
before update on public.mi_nucleo_profiles
for each row execute function public.mi_nucleo_touch_updated_at();

drop trigger if exists mi_nucleo_product_access_touch on public.mi_nucleo_product_access;
create trigger mi_nucleo_product_access_touch
before update on public.mi_nucleo_product_access
for each row execute function public.mi_nucleo_touch_updated_at();

create or replace function public.mi_nucleo_handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.mi_nucleo_profiles (user_id, full_name)
  values (
    new.id,
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name', '')), '')
  )
  on conflict (user_id) do update
    set full_name = coalesce(excluded.full_name, public.mi_nucleo_profiles.full_name);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_mi_nucleo on auth.users;
create trigger on_auth_user_created_mi_nucleo
after insert on auth.users
for each row execute function public.mi_nucleo_handle_new_user();

insert into public.mi_nucleo_profiles (user_id, full_name)
select
  id,
  nullif(trim(coalesce(raw_user_meta_data ->> 'full_name', raw_user_meta_data ->> 'name', '')), '')
from auth.users
on conflict (user_id) do nothing;

alter table public.mi_nucleo_profiles enable row level security;
alter table public.mi_nucleo_consents enable row level security;
alter table public.mi_nucleo_product_access enable row level security;

drop policy if exists "mi nucleo profiles own select" on public.mi_nucleo_profiles;
create policy "mi nucleo profiles own select"
on public.mi_nucleo_profiles for select
to authenticated
using (user_id = auth.uid());

drop policy if exists "mi nucleo profiles own insert" on public.mi_nucleo_profiles;
create policy "mi nucleo profiles own insert"
on public.mi_nucleo_profiles for insert
to authenticated
with check (user_id = auth.uid());

drop policy if exists "mi nucleo profiles own update" on public.mi_nucleo_profiles;
create policy "mi nucleo profiles own update"
on public.mi_nucleo_profiles for update
to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());

drop policy if exists "mi nucleo consents own select" on public.mi_nucleo_consents;
create policy "mi nucleo consents own select"
on public.mi_nucleo_consents for select
to authenticated
using (user_id = auth.uid());

drop policy if exists "mi nucleo consents own insert" on public.mi_nucleo_consents;
create policy "mi nucleo consents own insert"
on public.mi_nucleo_consents for insert
to authenticated
with check (user_id = auth.uid());

drop policy if exists "mi nucleo consents own update" on public.mi_nucleo_consents;
create policy "mi nucleo consents own update"
on public.mi_nucleo_consents for update
to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());

drop policy if exists "mi nucleo access own select" on public.mi_nucleo_product_access;
create policy "mi nucleo access own select"
on public.mi_nucleo_product_access for select
to authenticated
using (user_id = auth.uid());

grant usage on schema public to authenticated;
grant select, insert, update on public.mi_nucleo_profiles to authenticated;
grant select, insert, update on public.mi_nucleo_consents to authenticated;
grant select on public.mi_nucleo_product_access to authenticated;

commit;
